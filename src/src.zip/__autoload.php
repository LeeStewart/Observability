<?php declare(strict_types=1);


// namespace Observability;


//use PC;

spl_autoload_register(function ($class)
{
	// PC::debug(__DIR__ . DIRECTORY_SEPARATOR . 'client' . DIRECTORY_SEPARATOR . $class . '.class.php');
	// if (($class=='Trace') || (strpos($class, __NAMESPACE__) === 0))
	{
		$parts = explode("\\", $class);

		if (array_shift($parts) == "Observability")
		{
			$path = join(DIRECTORY_SEPARATOR, $parts);

			if (file_exists(__DIR__.DIRECTORY_SEPARATOR.$path.'.class.php'))
				require(__DIR__.DIRECTORY_SEPARATOR.$path.'.class.php');
			else
			{
				echo "<pre>";
				print_r(debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS));
				print_r((__DIR__.DIRECTORY_SEPARATOR.$path.'.class.php').PHP_EOL);
				print_r($parts);
				die("TEST");
			}
		}
	return;
		if (count($parts) == 2)
			$class = $parts[1];

		//stream_resolve_include_path

		if (file_exists(__DIR__ . DIRECTORY_SEPARATOR . 'client' . DIRECTORY_SEPARATOR . $class . '.class.php'))
			require(__DIR__ . DIRECTORY_SEPARATOR . 'client' . DIRECTORY_SEPARATOR . $class . '.class.php');

//		if (file_exists(__DIR__ . DIRECTORY_SEPARATOR . 'client' . DIRECTORY_SEPARATOR . $class . '.interface.php'))
//			require(__DIR__ . DIRECTORY_SEPARATOR . 'client' . DIRECTORY_SEPARATOR . $class . '.interface.php');

		if (file_exists(__DIR__ . DIRECTORY_SEPARATOR . 'server' . DIRECTORY_SEPARATOR . $class . '.class.php'))
			require(__DIR__ . DIRECTORY_SEPARATOR . 'server' . DIRECTORY_SEPARATOR . $class . '.class.php');
	}
});
