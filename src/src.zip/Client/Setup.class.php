<?php declare(strict_types=1);



namespace Observability\Client;




class Setup
{
	private static $initialized = false;
	private static $skipDisplay = false;

	/** @var Core\OutputInterface[] $outputInterfaces */
	private static $outputInterfaces = array();

	// How long did it take to execute this page?
	private static $startTimer = 0;



	private function __construct() {}



	public static function addOutputInterface($type, Core\OutputInterface $tracerOutput)
	{
		self::$outputInterfaces[$type] = $tracerOutput;
	}



	public static function startup()
	{
		if (self::$initialized)
			return;


		self::$startTimer = microtime(true);

		$params = self::formatStartupArguments();


		$tracerOutput = null;
		if ($params['server']['outputType'] == 'console')
		{
			$tracerOutput = new Core\OutputConsole();
		}
		else
		{
			$tracerOutput = new Core\OutputWeb();
		}

		$tracerOutput->skipDisplay(self::$skipDisplay);
		self::$outputInterfaces[$params['server']['outputType']] = $tracerOutput;

		// if Ajax, skip output.
		if ($params['server']['ajax'])
			self::skipDisplay(true);

		foreach (self::$outputInterfaces as $tracerOutput)
			$tracerOutput->startup($params);

		register_shutdown_function(array('Observability\Client\Config','shutdown'));

		self::$initialized = true;
	}



	public static function shutdown()
	{
		$params = self::formatShutdownArguments();
		foreach (self::$outputInterfaces as $tracerOutput)
			$tracerOutput->shutdown($params);

	}


	public static function skipDisplay($skip=true)
	{
		self::$skipDisplay = $skip;

		foreach (self::$outputInterfaces as $output)
			$output->skipDisplay(self::$skipDisplay);

	}

}
