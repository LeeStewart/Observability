<?php declare(strict_types=1);



namespace Observability\Client;




class Metrics
{


	private function __construct() {}

}
